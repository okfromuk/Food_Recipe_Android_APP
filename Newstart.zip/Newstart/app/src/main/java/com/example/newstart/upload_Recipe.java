package com.example.newstart;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class upload_Recipe extends AppCompatActivity {
ImageView iv_foodImage1;
Uri uri;
EditText RecipeName1,DescriptionID1,PriceID1;
Button SelectImageID1,UploadID1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload__recipe);


        iv_foodImage1=(ImageView)findViewById(R.id.iv_foodImage);
        RecipeName1 =(EditText)findViewById(R.id.RecipeName);
        DescriptionID1=(EditText)findViewById(R.id.DescriptionID);
        PriceID1=(EditText)findViewById(R.id.PriceID);
        SelectImageID1 =(Button)findViewById(R.id.SelectImageID);
        UploadID1=(Button)findViewById(R.id.UploadID);
    }

    public void selectImage(View view) {


        Intent photopicker=new Intent(Intent.ACTION_PICK);
        photopicker.setType("Image");
        startActivityForResult(photopicker,1);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK){

        uri=data.getData();
            iv_foodImage1.setImageURI(uri);


        }
        else      Toast.makeText(this,"You haven't Picked Any Image",Toast.LENGTH_SHORT).show();




    }
}
